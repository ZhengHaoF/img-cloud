// eslint-disable-next-line no-unused-vars
const serve_state = {
    dataServer:"http://localhost:8006/",//当前数据服务器
    storageServer:"http://localhost:8006/",//当前存储服务器
    uploadUrl: "index.php/upload",//当前上传接口
}